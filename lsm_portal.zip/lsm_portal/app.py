"""
Prime Vector LSM Portal – Main Application
==========================================
Flask application factory. Registers all blueprints.
Run with: python app.py
"""

from flask import Flask, render_template, redirect, url_for, session
from config.config import config
import os

# ------------------------------------------------------------------
# Blueprint Imports
# ------------------------------------------------------------------
from routes.auth import auth_bp
from routes.student import student_bp
from routes.mentor import mentor_bp
from routes.admin import admin_bp


def create_app(env: str = "development") -> Flask:
    """
    Application factory.
    Creates and configures the Flask application.

    Args:
        env: Environment name ('development' | 'production')

    Returns:
        Configured Flask application instance.
    """
    app = Flask(__name__)

    # ----------------------------------------------------------------
    # Load Configuration
    # ----------------------------------------------------------------
    app.config.from_object(config.get(env, config["default"]))

    # ----------------------------------------------------------------
    # Register Blueprints
    # ----------------------------------------------------------------
    app.register_blueprint(auth_bp)           # /login/student, /login/mentor, /login/admin, /logout
    app.register_blueprint(student_bp)        # /student/dashboard
    app.register_blueprint(mentor_bp)         # /mentor/dashboard
    app.register_blueprint(admin_bp)          # /admin/dashboard

    # ----------------------------------------------------------------
    # Landing / Root Routes
    # ----------------------------------------------------------------
    from flask import Blueprint
    main_bp = Blueprint("main", __name__)

    @main_bp.route("/")
    def landing():
        """Landing page with role selection."""
        return render_template("landing.html")

    @main_bp.route("/dashboard")
    def dashboard_redirect():
        """Smart redirect based on session role."""
        role = session.get("role")
        if role == "student":
            return redirect(url_for("student.dashboard"))
        elif role == "mentor":
            return redirect(url_for("mentor.dashboard"))
        elif role == "admin":
            return redirect(url_for("admin.dashboard"))
        return redirect(url_for("main.landing"))

    app.register_blueprint(main_bp)

    # ----------------------------------------------------------------
    # Error Handlers
    # ----------------------------------------------------------------
    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(500)
    def server_error(e):
        return render_template("errors/500.html"), 500

    return app


# ------------------------------------------------------------------
# Entry Point
# ------------------------------------------------------------------
if __name__ == "__main__":
    env = os.environ.get("FLASK_ENV", "development")
    app = create_app(env)
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=(env == "development")
    )
