"""
Prime Vector LSM Portal – Data Manager Utility
============================================================
Provides a clean abstraction layer over JSON file storage.
Designed for MongoDB migration: simply swap the implementation of each
method with pymongo equivalents without touching route code.
"""

import json
import uuid
from pathlib import Path
from datetime import datetime


class DataManager:
    """
    Handles all CRUD operations against JSON data files.
    Each 'collection' maps to a <collection>.json file in the data directory.

    MongoDB migration guide:
    - Replace `self.data_dir / f"{collection}.json"` with `db[collection]`
    - Replace json read/write with pymongo find/insert/update/delete
    """

    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _file(self, collection: str) -> Path:
        """Return the Path object for the given collection JSON file."""
        return self.data_dir / f"{collection}.json"

    def _read_raw(self, collection: str):
        """Load raw JSON (list or dict) from a collection file."""
        file = self._file(collection)
        if not file.exists():
            return []
        with open(file, "r", encoding="utf-8") as f:
            return json.load(f)

    def _read(self, collection: str) -> list:
        """
        Load all records from a JSON collection file.
        Always returns a list of records.
        If the JSON root is a dict, wrap it in a list.
        """
        data = self._read_raw(collection)
        if isinstance(data, list):
            return data
        # It's a single dict (e.g. dashboard.json) – wrap so callers work
        return [data]

    def _write(self, collection: str, records) -> None:
        """Persist records back to a JSON collection file."""
        file = self._file(collection)
        with open(file, "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, ensure_ascii=False, default=str)

    # ------------------------------------------------------------------
    # Special helper for dict-type config files (e.g. dashboard.json)
    # ------------------------------------------------------------------

    def get_dict(self, collection: str) -> dict:
        """
        Return the root dict for a collection whose JSON root is a dict.
        Safe fallback to empty dict if not found or not a dict.
        """
        data = self._read_raw(collection)
        if isinstance(data, dict):
            return data
        return {}

    # ------------------------------------------------------------------
    # CRUD API (MongoDB-compatible signatures)
    # ------------------------------------------------------------------

    def get_all(self, collection: str) -> list:
        """Return all records from the collection. Equivalent to find()."""
        return self._read(collection)

    def get_by_id(self, collection: str, record_id: str) -> dict | None:
        """Return a single record by its 'id' field. Equivalent to find_one({'id': id})."""
        records = self._read(collection)
        for record in records:
            if isinstance(record, dict) and str(record.get("id")) == str(record_id):
                return record
        return None

    def find_one(self, collection: str, query: dict) -> dict | None:
        """Return first record matching all key-value pairs in query."""
        records = self._read(collection)
        for record in records:
            if not isinstance(record, dict):
                continue
            if all(str(record.get(k)) == str(v) for k, v in query.items()):
                return record
        return None

    def find_many(self, collection: str, query: dict) -> list:
        """Return all records matching all key-value pairs in query."""
        records = self._read(collection)
        result = []
        for record in records:
            if not isinstance(record, dict):
                continue
            if all(str(record.get(k)) == str(v) for k, v in query.items()):
                result.append(record)
        return result

    def email_exists(self, collection: str, email: str, exclude_id: str = None) -> bool:
        """Check if an email already exists in the collection."""
        records = self._read(collection)
        for record in records:
            if not isinstance(record, dict):
                continue
            if str(record.get("id")) == str(exclude_id):
                continue
            if record.get("email", "").lower() == email.lower():
                return True
        return False

    def create(self, collection: str, data: dict) -> dict:
        """Insert a new record. Equivalent to insert_one()."""
        records = self._read(collection)
        if "id" not in data or not data["id"]:
            # Generate short readable ID like s009, m005, a003
            prefix_map = {
                "students": "s", "mentors": "m",
                "admins": "a", "assignments": "asn",
                "courses": "c", "announcements": "ann",
            }
            prefix = prefix_map.get(collection, "x")
            data["id"] = f"{prefix}{str(uuid.uuid4())[:6]}"
        if "created_at" not in data:
            data["created_at"] = datetime.now().isoformat()
        records.append(data)
        self._write(collection, records)
        return data

    def update(self, collection: str, record_id: str, updates: dict) -> dict | None:
        """Update a record by id. Equivalent to update_one({'id': id}, {'$set': updates})."""
        records = self._read(collection)
        for i, record in enumerate(records):
            if not isinstance(record, dict):
                continue
            if str(record.get("id")) == str(record_id):
                records[i].update(updates)
                records[i]["updated_at"] = datetime.now().isoformat()
                self._write(collection, records)
                return records[i]
        return None

    def delete(self, collection: str, record_id: str) -> bool:
        """Delete a record by id. Equivalent to delete_one({'id': id})."""
        records = self._read(collection)
        new_records = [r for r in records if isinstance(r, dict) and str(r.get("id")) != str(record_id)]
        if len(new_records) < len(records):
            self._write(collection, new_records)
            return True
        return False

    def count(self, collection: str, query: dict = None) -> int:
        """Count records, optionally filtered by query."""
        if query:
            return len(self.find_many(collection, query))
        return len(self._read(collection))
