"""
Prime Vector LSM Portal – Authentication Routes
Handles login, logout, and session management for all three roles.
"""

from flask import (
    Blueprint, render_template, request,
    redirect, url_for, session, jsonify, flash
)
from functools import wraps
from utils.data_manager import DataManager
from pathlib import Path
import os

# ------------------------------------------------------------------
# Blueprint Setup
# ------------------------------------------------------------------
auth_bp = Blueprint("auth", __name__)

# Initialise data manager (DATA_DIR resolved relative to this file)
_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


# ------------------------------------------------------------------
# Login Required Decorators
# ------------------------------------------------------------------

def student_required(f):
    """Decorator – ensures user is logged in as a student."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "student":
            flash("Please log in as a student to access this page.", "warning")
            return redirect(url_for("auth.login_student"))
        return f(*args, **kwargs)
    return decorated


def mentor_required(f):
    """Decorator – ensures user is logged in as a mentor."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "mentor":
            flash("Please log in as a mentor to access this page.", "warning")
            return redirect(url_for("auth.login_mentor"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    """Decorator – ensures user is logged in as an admin."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Please log in as an admin to access this page.", "warning")
            return redirect(url_for("auth.login_admin"))
        return f(*args, **kwargs)
    return decorated


# ------------------------------------------------------------------
# Student Login
# ------------------------------------------------------------------

@auth_bp.route("/login/student", methods=["GET", "POST"])
def login_student():
    """Render and process the student login form."""
    if session.get("role") == "student":
        return redirect(url_for("student.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        # Validate credentials against students.json
        student = dm.find_one("students", {"email": email})
        if student and student.get("password") == password:
            session["role"] = "student"
            session["user_id"] = student["id"]
            session["user_name"] = student["name"]
            session["user_email"] = student["email"]
            session["user_avatar"] = student.get("avatar", "ST")
            if remember:
                session.permanent = True
            return jsonify({"success": True, "redirect": url_for("student.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_student.html")


# ------------------------------------------------------------------
# Mentor Login
# ------------------------------------------------------------------

@auth_bp.route("/login/mentor", methods=["GET", "POST"])
def login_mentor():
    """Render and process the mentor login form."""
    if session.get("role") == "mentor":
        return redirect(url_for("mentor.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        mentor = dm.find_one("mentors", {"email": email})
        if mentor and mentor.get("password") == password:
            session["role"] = "mentor"
            session["user_id"] = mentor["id"]
            session["user_name"] = mentor["name"]
            session["user_email"] = mentor["email"]
            session["user_avatar"] = mentor.get("avatar", "MT")
            if remember:
                session.permanent = True
            return jsonify({"success": True, "redirect": url_for("mentor.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_mentor.html")


# ------------------------------------------------------------------
# Admin Login
# ------------------------------------------------------------------

@auth_bp.route("/login/admin", methods=["GET", "POST"])
def login_admin():
    """Render and process the admin login form."""
    if session.get("role") == "admin":
        return redirect(url_for("admin.dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        remember = request.form.get("remember", False)

        admin = dm.find_one("admins", {"email": email})
        if admin and admin.get("password") == password:
            session["role"] = "admin"
            session["user_id"] = admin["id"]
            session["user_name"] = admin["name"]
            session["user_email"] = admin["email"]
            session["user_avatar"] = admin.get("avatar", "AD")
            if remember:
                session.permanent = True
            return jsonify({"success": True, "redirect": url_for("admin.dashboard")})
        else:
            return jsonify({"success": False, "message": "Invalid email or password. Please try again."})

    return render_template("auth/login_admin.html")


# ------------------------------------------------------------------
# Logout
# ------------------------------------------------------------------

@auth_bp.route("/logout")
def logout():
    """Clear session and redirect to landing page."""
    role = session.get("role", "student")
    session.clear()
    flash("You have been logged out successfully.", "info")
    return redirect(url_for("main.landing"))
