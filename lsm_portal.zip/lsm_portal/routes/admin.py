"""
Prime Vector LSM Portal – Admin Routes
All protected routes for the admin dashboard.
"""

from flask import Blueprint, render_template, session, jsonify, request
from pathlib import Path
from datetime import datetime
from utils.data_manager import DataManager
from routes.auth import admin_required

admin_bp = Blueprint("admin", __name__, url_prefix="/admin")

_BASE = Path(__file__).resolve().parent.parent
dm = DataManager(_BASE / "data")


@admin_bp.route("/dashboard")
@admin_required
def dashboard():
    """Main admin dashboard – system-wide statistics and management."""
    # Load all collections
    students = dm.get_all("students")
    mentors = dm.get_all("mentors")
    courses = dm.get_all("courses")
    assignments = dm.get_all("assignments")
    announcements = dm.get_all("announcements")
    admins = dm.get_all("admins")
    dashboard_data = dm.find_one("dashboard", {}) or {}

    # Admin profile
    user_id = session.get("user_id")
    admin = dm.get_by_id("admins", user_id)

    # Notifications for admin
    all_notifications = dm.get_all("notifications")
    my_notifications = [n for n in all_notifications if n.get("user_id") == user_id]
    unread_count = sum(1 for n in my_notifications if not n.get("read", True))

    # Platform statistics
    stats = {
        "total_students": len(students),
        "total_mentors": len(mentors),
        "total_courses": len(courses),
        "total_assignments": len(assignments),
        "certificates_issued": dashboard_data.get("platform_stats", {}).get("certificates_issued", 0),
        "active_sessions": dashboard_data.get("platform_stats", {}).get("active_sessions", 0),
        "success_rate": dashboard_data.get("platform_stats", {}).get("success_rate", 0),
        "avg_rating": dashboard_data.get("platform_stats", {}).get("avg_course_rating", 0),
    }

    # Recent logins from dashboard.json
    recent_logins = dashboard_data.get("recent_logins", [])

    # Dynamic course popularity chart data based on enrolled count
    course_popularity = {
        "labels": [c["title"] for c in courses],
        "data": [c.get("enrolled_count", 0) for c in courses]
    }
    dashboard_data["course_popularity"] = course_popularity

    # Load system configuration settings
    settings = dm.get_dict("settings")
    if not settings:
        settings = {
            "app_name": "Prime Vector",
            "tagline": "Your vector towards success",
            "email": "primevectorprivatelimited@gmail.com",
            "phone": "+91 8220082896",
            "address": "No.74/22f11, 3rd Floor, HV Arcade, Bagalur Road, Hosur, Krishnagiri, Tamil Nadu - 635109",
            "maintenance_mode": "no",
            "allow_registrations": "yes",
            "logo_url": "/static/images/primevector_logo.png"
        }

    return render_template(
        "admin/dashboard.html",
        admin=admin,
        admins=admins,
        students=students,
        mentors=mentors,
        courses=courses,
        stats=stats,
        announcements=announcements,
        recent_logins=recent_logins,
        dashboard_data=dashboard_data,
        notifications=my_notifications,
        unread_count=unread_count,
        settings=settings,
    )


@admin_bp.route("/announcement/create", methods=["POST"])
@admin_required
def create_announcement():
    """Create a new announcement (AJAX)."""
    data = request.get_json()
    announcement = {
        "title": data.get("title"),
        "content": data.get("content"),
        "author": session.get("user_name"),
        "author_role": "admin",
        "target_roles": data.get("target_roles", ["student", "mentor"]),
        "priority": data.get("priority", "medium"),
        "pinned": data.get("pinned", False),
        "icon": data.get("icon", "📢"),
        "date": datetime.now().strftime("%Y-%m-%d")
    }
    result = dm.create("announcements", announcement)
    return jsonify({"success": True, "announcement": result})


@admin_bp.route("/students", methods=["GET"])
@admin_required
def get_students():
    """Return all students as JSON (AJAX)."""
    students = dm.get_all("students")
    safe = [{k: v for k, v in s.items() if k != "password"} for s in students]
    return jsonify(safe)


@admin_bp.route("/mentors", methods=["GET"])
@admin_required
def get_mentors():
    """Return all mentors as JSON (AJAX)."""
    mentors = dm.get_all("mentors")
    safe = [{k: v for k, v in m.items() if k != "password"} for m in mentors]
    return jsonify(safe)


# ------------------------------------------------------------------
# Admin CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/create", methods=["POST"])
@admin_required
def create_admin():
    """Create a new admin (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("admins", email) or dm.email_exists("students", email) or dm.email_exists("mentors", email):
        return jsonify({"success": False, "message": "Email already exists in system."})
        
    name = data.get("name", "").strip()
    new_admin = {
        "name": name,
        "email": email,
        "password": data.get("password", "admin123"),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "role": data.get("role", "admin"),
        "phone": data.get("phone", ""),
        "joined_date": datetime.now().strftime("%Y-%m-%d"),
        "location": data.get("location", "")
    }
    result = dm.create("admins", new_admin)
    return jsonify({"success": True, "admin": result})


@admin_bp.route("/edit/<admin_id>", methods=["POST"])
@admin_required
def edit_admin(admin_id):
    """Edit an existing admin (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("admins", email, exclude_id=admin_id):
        return jsonify({"success": False, "message": "Email already exists."})
        
    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "role": data.get("role", "admin"),
        "phone": data.get("phone", ""),
        "location": data.get("location", "")
    }
    if data.get("password"):
        updates["password"] = data.get("password")
        
    result = dm.update("admins", admin_id, updates)
    return jsonify({"success": True, "admin": result})


@admin_bp.route("/delete/<admin_id>", methods=["POST"])
@admin_required
def delete_admin(admin_id):
    """Delete an admin (AJAX)."""
    if str(admin_id) == str(session.get("user_id")):
        return jsonify({"success": False, "message": "You cannot delete your own account."})
        
    result = dm.delete("admins", admin_id)
    return jsonify({"success": result})


# ------------------------------------------------------------------
# Student CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/student/create", methods=["POST"])
@admin_required
def create_student():
    """Create a new student (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("students", email) or dm.email_exists("admins", email) or dm.email_exists("mentors", email):
        return jsonify({"success": False, "message": "Email already exists in system."})
        
    name = data.get("name", "").strip()
    student = {
        "name": name,
        "email": email,
        "password": data.get("password", "student123"),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "batch": data.get("batch", "Batch-2024-C"),
        "enrolled_date": datetime.now().strftime("%Y-%m-%d"),
        "courses_enrolled": data.get("courses_enrolled", []),
        "overall_progress": int(data.get("overall_progress", 0)),
        "grade": data.get("grade", "B"),
        "assignments_submitted": 0,
        "assignments_total": 0,
        "certificates_earned": 0,
        "streak_days": 0,
        "last_active": datetime.now().strftime("%Y-%m-%d"),
        "bio": data.get("bio", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()],
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", "")
    }
    
    result = dm.create("students", student)
    return jsonify({"success": True, "student": result})


@admin_bp.route("/student/edit/<student_id>", methods=["POST"])
@admin_required
def edit_student(student_id):
    """Edit an existing student (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("students", email, exclude_id=student_id):
        return jsonify({"success": False, "message": "Email already exists."})
        
    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "batch": data.get("batch", "Batch-2024-C"),
        "courses_enrolled": data.get("courses_enrolled", []),
        "overall_progress": int(data.get("overall_progress", 0)),
        "grade": data.get("grade", "B"),
        "bio": data.get("bio", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()],
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", "")
    }
    if data.get("password"):
        updates["password"] = data.get("password")
        
    result = dm.update("students", student_id, updates)
    return jsonify({"success": True, "student": result})


@admin_bp.route("/student/delete/<student_id>", methods=["POST"])
@admin_required
def delete_student(student_id):
    """Delete a student (AJAX)."""
    result = dm.delete("students", student_id)
    return jsonify({"success": result})


# ------------------------------------------------------------------
# Mentor CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/mentor/create", methods=["POST"])
@admin_required
def create_mentor():
    """Create a new mentor (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("mentors", email) or dm.email_exists("admins", email) or dm.email_exists("students", email):
        return jsonify({"success": False, "message": "Email already exists in system."})
        
    name = data.get("name", "").strip()
    mentor = {
        "name": name,
        "email": email,
        "password": data.get("password", "mentor123"),
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "specialty": data.get("specialty", ""),
        "experience_years": int(data.get("experience_years", 5)),
        "rating": 4.5,
        "bio": data.get("bio", ""),
        "courses_assigned": data.get("courses_assigned", []),
        "students_assigned": [],
        "total_students_mentored": 0,
        "certificates_issued": 0,
        "joined_date": datetime.now().strftime("%Y-%m-%d"),
        "qualification": data.get("qualification", ""),
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()]
    }
    
    result = dm.create("mentors", mentor)
    
    # Sync with courses assigned
    for cid in mentor["courses_assigned"]:
        dm.update("courses", cid, {"mentor_id": result["id"], "mentor_name": name})
        
    return jsonify({"success": True, "mentor": result})


@admin_bp.route("/mentor/edit/<mentor_id>", methods=["POST"])
@admin_required
def edit_mentor(mentor_id):
    """Edit an existing mentor (AJAX)."""
    data = request.get_json()
    email = data.get("email", "").strip().lower()
    
    if dm.email_exists("mentors", email, exclude_id=mentor_id):
        return jsonify({"success": False, "message": "Email already exists."})
        
    name = data.get("name", "").strip()
    updates = {
        "name": name,
        "email": email,
        "avatar": "".join([part[0].upper() for part in name.split() if part][:2]),
        "phone": data.get("phone", ""),
        "specialty": data.get("specialty", ""),
        "experience_years": int(data.get("experience_years", 5)),
        "bio": data.get("bio", ""),
        "courses_assigned": data.get("courses_assigned", []),
        "qualification": data.get("qualification", ""),
        "linkedin": data.get("linkedin", ""),
        "location": data.get("location", ""),
        "skills": [s.strip() for s in data.get("skills", "").split(",") if s.strip()]
    }
    if data.get("password"):
        updates["password"] = data.get("password")
        
    result = dm.update("mentors", mentor_id, updates)
    
    # Update courses with mentor name
    for cid in updates["courses_assigned"]:
        dm.update("courses", cid, {"mentor_id": mentor_id, "mentor_name": name})
        
    return jsonify({"success": True, "mentor": result})


@admin_bp.route("/mentor/delete/<mentor_id>", methods=["POST"])
@admin_required
def delete_mentor(mentor_id):
    """Delete a mentor (AJAX)."""
    result = dm.delete("mentors", mentor_id)
    return jsonify({"success": result})


# ------------------------------------------------------------------
# Course CRUD operations
# ------------------------------------------------------------------

@admin_bp.route("/course/create", methods=["POST"])
@admin_required
def create_course():
    """Create a new course (AJAX)."""
    data = request.get_json()
    title = data.get("title", "").strip()
    
    # Check if mentor exists
    mentor_id = data.get("mentor_id")
    mentor = dm.get_by_id("mentors", mentor_id)
    mentor_name = mentor.get("name", "Unknown Mentor") if mentor else "Unknown Mentor"
    
    course = {
        "title": title,
        "slug": "-".join(title.lower().split()),
        "description": data.get("description", ""),
        "category": data.get("category", "General"),
        "level": data.get("level", "Beginner"),
        "duration_weeks": int(data.get("duration_weeks", 8)),
        "lessons_total": int(data.get("lessons_total", 32)),
        "price_original": int(data.get("price_original", 13000)),
        "price_current": int(data.get("price_current", 6550)),
        "rating": 4.5,
        "enrolled_count": 0,
        "mentor_id": mentor_id,
        "mentor_name": mentor_name,
        "thumbnail_color": data.get("thumbnail_color", "#4facfe"),
        "icon": data.get("icon", "📚"),
        "topics": [t.strip() for t in data.get("topics", "").split(",") if t.strip()],
        "certificate": True,
        "status": data.get("status", "active")
    }
    result = dm.create("courses", course)
    
    # Update mentor's courses_assigned list
    if mentor:
        assigned = mentor.get("courses_assigned", [])
        if result["id"] not in assigned:
            assigned.append(result["id"])
            dm.update("mentors", mentor_id, {"courses_assigned": assigned})
            
    return jsonify({"success": True, "course": result})


@admin_bp.route("/course/edit/<course_id>", methods=["POST"])
@admin_required
def edit_course(course_id):
    """Edit an existing course (AJAX)."""
    data = request.get_json()
    title = data.get("title", "").strip()
    mentor_id = data.get("mentor_id")
    mentor = dm.get_by_id("mentors", mentor_id)
    mentor_name = mentor.get("name", "Unknown Mentor") if mentor else "Unknown Mentor"
    
    updates = {
        "title": title,
        "slug": "-".join(title.lower().split()),
        "description": data.get("description", ""),
        "category": data.get("category", "General"),
        "level": data.get("level", "Beginner"),
        "duration_weeks": int(data.get("duration_weeks", 8)),
        "lessons_total": int(data.get("lessons_total", 32)),
        "price_original": int(data.get("price_original", 13000)),
        "price_current": int(data.get("price_current", 6550)),
        "mentor_id": mentor_id,
        "mentor_name": mentor_name,
        "thumbnail_color": data.get("thumbnail_color", "#4facfe"),
        "icon": data.get("icon", "📚"),
        "topics": [t.strip() for t in data.get("topics", "").split(",") if t.strip()],
        "status": data.get("status", "active")
    }
    result = dm.update("courses", course_id, updates)
    
    # Sync with mentor lists
    if mentor:
        assigned = mentor.get("courses_assigned", [])
        if course_id not in assigned:
            assigned.append(course_id)
            dm.update("mentors", mentor_id, {"courses_assigned": assigned})
            
    return jsonify({"success": True, "course": result})


@admin_bp.route("/course/delete/<course_id>", methods=["POST"])
@admin_required
def delete_course(course_id):
    """Delete a course (AJAX)."""
    result = dm.delete("courses", course_id)
    return jsonify({"success": result})


@admin_bp.route("/settings/save", methods=["POST"])
@admin_required
def save_settings():
    """Save system settings (AJAX)."""
    data = request.get_json()
    updates = {
        "app_name": data.get("app_name", "Prime Vector"),
        "tagline": data.get("tagline", "Your vector towards success"),
        "email": data.get("email", ""),
        "phone": data.get("phone", ""),
        "address": data.get("address", ""),
        "maintenance_mode": data.get("maintenance_mode", "no"),
        "allow_registrations": data.get("allow_registrations", "yes"),
        "logo_url": "/static/images/primevector_logo.png"
    }
    dm._write("settings", updates)
    return jsonify({"success": True, "settings": updates})
