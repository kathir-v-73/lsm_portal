/**
 * Prime Vector LSM Portal – Landing Page JavaScript
 * landing.js
 */

document.addEventListener('DOMContentLoaded', function () {
  console.log('[Landing] Document ready');
  console.log('[Landing] VANTA:', typeof window.VANTA !== 'undefined' ? 'loaded' : 'NOT loaded');
  console.log('[Landing] THREE:', typeof window.THREE !== 'undefined' ? 'loaded' : 'NOT loaded');
  
  // Initialize Vanta BIRDS effect
  if (window.VANTA && window.THREE) {
    try {
      console.log('[Landing] Initializing Vanta BIRDS effect...');
      VANTA.BIRDS({
        el: '#vanta-container',
        THREE: window.THREE,
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200,
        minWidth: 200,
        scale: 1.0,
        scaleMobile: 1.0,
        backgroundColor: 0x0f172a,
        backgroundAlpha: 0.15,
        color1: 0x6366f1,
        color2: 0x0ea5e9,
        colorMode: 'variance',
        birdSize: 1.0,
        wingSpan: 30,
        speedLimit: 5,
        separation: 20,
        alignment: 20,
        cohesion: 20,
        quantity: 4,
        speed: 1.0,
        forceAnimate: true
      });
      console.log('[Landing] Vanta BIRDS effect initialized successfully!');
    } catch (error) {
      console.error('[Landing] Error initializing Vanta BIRDS:', error);
    }
  } else {
    console.warn('[Landing] VANTA or THREE not loaded. VANTA:', window.VANTA, 'THREE:', window.THREE);
  }

  // Smooth reveal animations for sections as user scrolls
  const revealElements = document.querySelectorAll('.login-card, .course-card-landing, .stats-banner-item');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  revealElements.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    revealObserver.observe(el);
  });
});
