/**
 * Prime Vector LSM Portal – Global JavaScript Utilities
 * main.js
 * 
 * Shared functions used across all pages:
 * – Page loader
 * – Toast notifications
 * – Button ripple effects
 * – Navbar scroll behavior
 * – Progress bar animations
 * – Sidebar toggle
 * – Profile dropdown
 * – Section switching
 */

/* =========================================================================
   1. Page Loader
   ========================================================================= */
document.addEventListener('DOMContentLoaded', function () {
  const loader = document.getElementById('page-loader');
  if (loader) {
    // Hide loader after a short delay (simulate loading)
    setTimeout(() => {
      loader.classList.add('hidden');
      setTimeout(() => {
        loader.style.display = 'none';
      }, 500);
    }, 800);
  }

  // Initialize all global features
  initButtonRipples();
  initNavbarScroll();
  initProgressBars();
  initSidebar();
  initProfileDropdown();
  initSectionSwitching();
  initCounterAnimation();
  initCalendarWidget();
});


/* =========================================================================
   2. Toast Notifications
   ========================================================================= */

/**
 * Show a toast notification.
 * @param {string} message - The message to display.
 * @param {string} type - 'success' | 'error' | 'warning' | 'info'
 * @param {string} [title] - Optional title.
 * @param {number} [duration=4000] - Auto-dismiss after ms.
 */
function showToast(message, type = 'info', title = '', duration = 4000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  // Icon & colour mapping
  const config = {
    success: { icon: '✅', color: 'var(--success)' },
    error:   { icon: '❌', color: 'var(--danger)' },
    warning: { icon: '⚠️', color: 'var(--warning)' },
    info:    { icon: 'ℹ️',  color: 'var(--primary)' },
  };

  const { icon, color } = config[type] || config.info;
  const toastTitle = title || { success: 'Success', error: 'Error', warning: 'Warning', info: 'Info' }[type] || 'Notice';

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.style.borderColor = color;
  toast.innerHTML = `
    <div class="toast-icon">${icon}</div>
    <div class="toast-content">
      <div class="toast-title">${toastTitle}</div>
      <div class="toast-message">${message}</div>
    </div>
    <button class="toast-close" onclick="dismissToast(this.parentElement)">×</button>
  `;

  container.appendChild(toast);

  // Auto-dismiss
  if (duration > 0) {
    setTimeout(() => dismissToast(toast), duration);
  }
}

function dismissToast(toast) {
  if (!toast) return;
  toast.classList.add('toast-out');
  toast.addEventListener('animationend', () => toast.remove(), { once: true });
}


/* =========================================================================
   3. Button Ripple Effect
   ========================================================================= */
function initButtonRipples() {
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', function (e) {
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = `${size}px`;
      ripple.style.left = `${e.clientX - rect.left - size / 2}px`;
      ripple.style.top  = `${e.clientY - rect.top - size / 2}px`;
      this.appendChild(ripple);
      ripple.addEventListener('animationend', () => ripple.remove(), { once: true });
    });
  });
}


/* =========================================================================
   4. Navbar Scroll Behavior (landing page)
   ========================================================================= */
function initNavbarScroll() {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;

  const navToggle = document.getElementById('nav-toggle');
  const mobileNav = document.getElementById('mobile-nav');

  window.addEventListener('scroll', () => {
    navbar.classList.toggle('scrolled', window.scrollY > 30);
  }, { passive: true });

  if (navToggle && mobileNav) {
    navToggle.addEventListener('click', () => {
      mobileNav.classList.toggle('open');
      const isOpen = mobileNav.classList.contains('open');
      navToggle.innerHTML = isOpen
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });

    // Close on link click
    mobileNav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        mobileNav.classList.remove('open');
        navToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
      });
    });
  }
}


/* =========================================================================
   5. Animated Progress Bars
   ========================================================================= */
function initProgressBars() {
  /**
   * Animate all .progress-bar-fill elements to their data-width value.
   * Uses IntersectionObserver so they only animate when visible.
   */
  const fills = document.querySelectorAll('.progress-bar-fill[data-width]');
  if (!fills.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const fill = entry.target;
        const targetWidth = parseInt(fill.dataset.width, 10) || 0;
        // Small delay for visual effect
        setTimeout(() => {
          fill.style.width = `${targetWidth}%`;
        }, 200);
        observer.unobserve(fill);
      }
    });
  }, { threshold: 0.2 });

  fills.forEach(fill => observer.observe(fill));
}


/* =========================================================================
   6. Sidebar Toggle (Dashboard Pages)
   ========================================================================= */
function initSidebar() {
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('main-content');
  const collapseBtn = document.getElementById('sidebar-collapse-btn');
  const mobileToggle = document.getElementById('mobile-sidebar-toggle');

  if (!sidebar) return;

  // Desktop collapse
  if (collapseBtn) {
    collapseBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      if (mainContent) {
        mainContent.classList.toggle('expanded');
      }
    });
  }

  // Mobile open/close
  if (mobileToggle) {
    mobileToggle.addEventListener('click', () => {
      sidebar.classList.toggle('mobile-open');
    });

    // Close when clicking outside sidebar on mobile
    document.addEventListener('click', (e) => {
      if (window.innerWidth <= 1024) {
        if (!sidebar.contains(e.target) && !mobileToggle.contains(e.target)) {
          sidebar.classList.remove('mobile-open');
        }
      }
    });
  }
}


/* =========================================================================
   7. Profile Dropdown
   ========================================================================= */
function initProfileDropdown() {
  const trigger = document.getElementById('profile-dropdown-trigger');
  const dropdown = document.getElementById('profile-dropdown');

  if (!trigger || !dropdown) return;

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdown.classList.contains('open');
    closeAllDropdowns();
    if (!isOpen) {
      dropdown.classList.add('open');
      trigger.classList.add('open');
    }
  });

  document.addEventListener('click', closeAllDropdowns);
}

function closeAllDropdowns() {
  document.querySelectorAll('.profile-dropdown.open').forEach(d => d.classList.remove('open'));
  document.querySelectorAll('.topbar-profile.open').forEach(t => t.classList.remove('open'));
}


/* =========================================================================
   8. Section Switching (Dashboard SPA Navigation)
   ========================================================================= */
function initSectionSwitching() {
  const navItems = document.querySelectorAll('.sidebar-nav-item[data-section]');

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      const sectionName = item.getAttribute('data-section');
      switchSection(sectionName);

      // Update active state
      navItems.forEach(ni => ni.classList.remove('active'));
      item.classList.add('active');
    });
  });
}

/**
 * Switch to a named section in the dashboard.
 * @param {string} sectionName 
 */
function switchSection(sectionName) {
  // Hide all sections
  document.querySelectorAll('.dashboard-section').forEach(s => {
    s.style.display = 'none';
  });

  // Show target
  const target = document.getElementById(`section-${sectionName}`);
  if (target) {
    target.style.display = 'block';

    // Trigger progress bar animations in this section
    setTimeout(initProgressBars, 100);

    // Scroll to top
    const pageContent = document.querySelector('.page-content');
    if (pageContent) pageContent.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Update nav active state
  document.querySelectorAll('.sidebar-nav-item[data-section]').forEach(item => {
    item.classList.toggle('active', item.getAttribute('data-section') === sectionName);
  });
}


/* =========================================================================
   9. Counter Animation (Stats on landing page)
   ========================================================================= */
function initCounterAnimation() {
  const counters = document.querySelectorAll('[data-count]');
  if (!counters.length) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const target = parseInt(el.dataset.count, 10);
        animateCounter(el, 0, target, 1800);
        observer.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  counters.forEach(c => observer.observe(c));
}

function animateCounter(el, start, end, duration) {
  const startTime = performance.now();
  function update(timestamp) {
    const progress = Math.min((timestamp - startTime) / duration, 1);
    // Ease-out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * (end - start) + start);
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}


/* =========================================================================
   10. Calendar Widget
   ========================================================================= */
function initCalendarWidget() {
  const calWidget = document.getElementById('calendar-widget');
  if (!calWidget) return;

  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay(); // 0=Sun

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Event dates (simulate assignment due dates)
  const eventDates = [5, 8, 10, 12, 15, 18, 20, 22, 25];

  let html = '<div class="calendar-header">';
  html += `<span>${today.toLocaleString('default', { month: 'long' })} ${year}</span>`;
  html += '</div>';
  html += '<div class="calendar-grid">';

  // Day headers
  dayNames.forEach(d => { html += `<div class="cal-day header">${d}</div>`; });

  // Empty cells before first day
  for (let i = 0; i < firstDay; i++) {
    html += '<div class="cal-day"></div>';
  }

  // Day cells
  for (let d = 1; d <= daysInMonth; d++) {
    const isToday = d === today.getDate();
    const hasEvent = eventDates.includes(d);
    let cls = 'cal-day';
    if (isToday) cls += ' today';
    else if (hasEvent) cls += ' has-event';
    html += `<div class="${cls}" title="${hasEvent ? 'Assignment due' : ''}">${d}</div>`;
  }

  html += '</div>';
  calWidget.innerHTML = html;
}


/* =========================================================================
   11. Mark Notifications Read
   ========================================================================= */
function markAllRead() {
  fetch('/student/notifications/mark-read', { method: 'POST' })
    .then(r => r.json())
    .then(d => {
      if (d.success) {
        // Remove unread indicators
        document.querySelectorAll('.notification-item.unread').forEach(item => {
          item.classList.remove('unread');
          const dot = item.querySelector('.topbar-notification-count');
          if (dot) dot.remove();
        });
        // Clear notification badge
        const badge = document.querySelector('.topbar-notification-count');
        if (badge) badge.remove();
        const sidebarBadge = document.querySelector('#nav-notifications .sidebar-nav-item-badge');
        if (sidebarBadge) sidebarBadge.remove();
        showToast('All notifications marked as read.', 'success');
      }
    })
    .catch(() => showToast('Could not update notifications.', 'error'));
}


/* =========================================================================
   12. Smooth Scroll for landing page anchor links
   ========================================================================= */
document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});


/* =========================================================================
   13. Profile Edit Modal (Student Dashboard)
   ========================================================================= */
function openProfileModal() {
  document.getElementById('profile-modal-overlay')?.classList.add('active');
}

function closeProfileModal() {
  document.getElementById('profile-modal-overlay')?.classList.remove('active');
}

function saveProfile() {
  const data = {
    phone: document.getElementById('edit-phone')?.value,
    bio: document.getElementById('edit-bio')?.value,
    linkedin: document.getElementById('edit-linkedin')?.value,
    location: document.getElementById('edit-location')?.value,
  };

  fetch('/student/profile/update', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
    .then(r => r.json())
    .then(d => {
      closeProfileModal();
      showToast(d.message || 'Profile updated!', d.success ? 'success' : 'error');
    })
    .catch(() => {
      showToast('Profile update failed. Please try again.', 'error');
    });
}


/* =========================================================================
   14. Modal Overlay click-outside to close
   ========================================================================= */
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', function (e) {
    if (e.target === this) {
      this.classList.remove('active');
    }
  });
});
