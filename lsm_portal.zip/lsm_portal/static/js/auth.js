/**
 * Prime Vector LSM Portal – Authentication JavaScript
 * auth.js
 * 
 * Handles: form validation, password toggle, AJAX login,
 *          loading animations, success/error feedback.
 */

document.addEventListener('DOMContentLoaded', function () {

  /* -----------------------------------------------------------------------
     Password visibility toggle
     ----------------------------------------------------------------------- */
  const passwordInput = document.getElementById('password');
  const toggleBtn     = document.getElementById('toggle-password');
  const eyeIcon       = document.getElementById('pass-eye-icon');

  if (toggleBtn && passwordInput) {
    toggleBtn.addEventListener('click', () => {
      const isHidden = passwordInput.type === 'password';
      passwordInput.type = isHidden ? 'text' : 'password';
      eyeIcon.className = isHidden ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
    });
  }

  /* -----------------------------------------------------------------------
     Form validation helpers
     ----------------------------------------------------------------------- */
  function showFieldError(fieldId, show = true) {
    const errEl = document.getElementById(`${fieldId}-error`);
    const inputEl = document.getElementById(fieldId);
    if (!errEl || !inputEl) return;
    errEl.style.display = show ? 'flex' : 'none';
    inputEl.classList.toggle('is-error', show);
    inputEl.classList.toggle('is-success', !show && inputEl.value.trim() !== '');
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function clearErrors() {
    ['email', 'password'].forEach(id => showFieldError(id, false));
    const errorMsg = document.getElementById('auth-error');
    if (errorMsg) errorMsg.classList.remove('visible');
  }

  /* -----------------------------------------------------------------------
     Login form submission
     ----------------------------------------------------------------------- */
  const loginForm = document.getElementById('login-form');
  const loginBtn  = document.getElementById('login-btn');

  if (!loginForm || !loginBtn) return;

  loginForm.addEventListener('submit', async function (e) {
    e.preventDefault();
    clearErrors();

    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const remember = document.getElementById('remember')?.checked ? 'on' : '';

    // Client-side validation
    let hasError = false;

    if (!validateEmail(email)) {
      showFieldError('email', true);
      hasError = true;
    }

    if (!password) {
      showFieldError('password', true);
      hasError = true;
    }

    if (hasError) return;

    // Show loading state
    loginBtn.classList.add('loading');
    loginBtn.disabled = true;

    try {
      // Send AJAX login request
      const formData = new FormData();
      formData.append('email', email);
      formData.append('password', password);
      if (remember) formData.append('remember', remember);

      const response = await fetch(LOGIN_ENDPOINT, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        // Show success overlay
        const successOverlay = document.getElementById('auth-success');
        if (successOverlay) successOverlay.classList.add('active');

        // Redirect after a short delay
        setTimeout(() => {
          window.location.href = data.redirect;
        }, 1200);
      } else {
        // Show error message
        const errorEl = document.getElementById('auth-error');
        const errorText = document.getElementById('auth-error-text');
        if (errorEl && errorText) {
          errorText.textContent = data.message || 'Invalid credentials. Please try again.';
          errorEl.classList.add('visible');
        }

        // Shake the form
        loginForm.style.animation = 'none';
        loginForm.offsetHeight; // reflow
        loginForm.style.animation = 'shake 0.4s ease';

        loginBtn.classList.remove('loading');
        loginBtn.disabled = false;
      }
    } catch (err) {
      const errorEl = document.getElementById('auth-error');
      if (errorEl) {
        document.getElementById('auth-error-text').textContent = 'Network error. Please check your connection.';
        errorEl.classList.add('visible');
      }
      loginBtn.classList.remove('loading');
      loginBtn.disabled = false;
    }
  });

  /* -----------------------------------------------------------------------
     Real-time validation on input
     ----------------------------------------------------------------------- */
  document.getElementById('email')?.addEventListener('blur', function () {
    if (this.value.trim() && !validateEmail(this.value.trim())) {
      showFieldError('email', true);
    } else {
      showFieldError('email', false);
    }
  });

  document.getElementById('password')?.addEventListener('input', function () {
    if (this.value.length > 0) {
      showFieldError('password', false);
    }
  });
});

/* -----------------------------------------------------------------------
   Shake animation style (injected dynamically)
   ----------------------------------------------------------------------- */
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `
  @keyframes shake {
    0%, 100% { transform: translateX(0); }
    15%       { transform: translateX(-6px); }
    30%       { transform: translateX(6px); }
    45%       { transform: translateX(-4px); }
    60%       { transform: translateX(4px); }
    75%       { transform: translateX(-2px); }
    90%       { transform: translateX(2px); }
  }
`;
document.head.appendChild(shakeStyle);
