/**
 * Prime Vector LSM Portal – Student Dashboard JavaScript
 * student.js
 * 
 * Initialises Chart.js charts for the student dashboard.
 * All data comes from the STUDENT_DATA object injected by the template.
 */

document.addEventListener('DOMContentLoaded', function () {

  /* -----------------------------------------------------------------------
     Performance Radar / Line Chart (Overview section)
     ----------------------------------------------------------------------- */
  const perfCtx = document.getElementById('performanceChart');
  if (perfCtx && typeof STUDENT_DATA !== 'undefined') {
    new Chart(perfCtx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Progress %',
          data: [
            Math.max(0, STUDENT_DATA.overall_progress - 35),
            Math.max(0, STUDENT_DATA.overall_progress - 22),
            Math.max(0, STUDENT_DATA.overall_progress - 15),
            Math.max(0, STUDENT_DATA.overall_progress - 8),
            Math.max(0, STUDENT_DATA.overall_progress - 3),
            STUDENT_DATA.overall_progress,
          ],
          fill: true,
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          borderColor: 'rgba(99, 102, 241, 0.8)',
          borderWidth: 2.5,
          tension: 0.4,
          pointBackgroundColor: 'rgba(99, 102, 241, 1)',
          pointRadius: 4,
          pointHoverRadius: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(15, 23, 42, 0.9)',
            titleColor: '#fff',
            bodyColor: 'rgba(255,255,255,0.8)',
            padding: 10,
            cornerRadius: 8,
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 11 }, color: '#9ca3af' },
          },
          y: {
            min: 0, max: 100,
            grid: { color: 'rgba(99, 102, 241, 0.06)' },
            ticks: {
              font: { size: 11 }, color: '#9ca3af',
              callback: v => `${v}%`,
            },
          },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Course Progress Bar Chart (Progress section)
     ----------------------------------------------------------------------- */
  const cpCtx = document.getElementById('courseProgressChart');
  if (cpCtx && typeof STUDENT_DATA !== 'undefined') {
    new Chart(cpCtx, {
      type: 'bar',
      data: {
        labels: STUDENT_DATA.courses,
        datasets: [{
          label: 'Progress %',
          data: STUDENT_DATA.progress,
          backgroundColor: STUDENT_DATA.progress.map(p =>
            p >= 75 ? 'rgba(34, 197, 94, 0.8)' :
            p >= 40 ? 'rgba(245, 158, 11, 0.8)' : 'rgba(239, 68, 68, 0.8)'
          ),
          borderRadius: 8,
          borderSkipped: false,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: { label: ctx => `${ctx.parsed.y}%` },
          },
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { font: { size: 10 }, maxRotation: 30, color: '#9ca3af' },
          },
          y: {
            min: 0, max: 100,
            grid: { color: 'rgba(0,0,0,0.04)' },
            ticks: { callback: v => `${v}%`, color: '#9ca3af', font: { size: 11 } },
          },
        },
      },
    });
  }

  /* -----------------------------------------------------------------------
     Grade Distribution Doughnut (Progress section)
     ----------------------------------------------------------------------- */
  const gradeCtx = document.getElementById('gradeChart');
  if (gradeCtx && typeof STUDENT_DATA !== 'undefined') {
    // Simulate grade distribution based on overall progress
    const prog = STUDENT_DATA.overall_progress;
    new Chart(gradeCtx, {
      type: 'doughnut',
      data: {
        labels: ['Completed', 'In Progress', 'Not Started'],
        datasets: [{
          data: [prog, Math.min(25, 100 - prog), Math.max(0, 100 - prog - 25)],
          backgroundColor: [
            'rgba(34, 197, 94, 0.85)',
            'rgba(99, 102, 241, 0.85)',
            'rgba(229, 231, 235, 0.85)',
          ],
          borderWidth: 0,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              font: { size: 11 },
              padding: 12,
              usePointStyle: true,
            },
          },
          tooltip: {
            callbacks: { label: ctx => `${ctx.label}: ${ctx.parsed}%` },
          },
        },
      },
    });
  }
});
